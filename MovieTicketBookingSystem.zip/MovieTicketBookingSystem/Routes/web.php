<?php

Route::get('/',function (Request $request){
    export('welcome',[]);
});

Route::get('/admin', 'Backend\LoginController@index');
Route::post('/admin', 'Backend\LoginController@adminLogin');
Route::get('/adminLogout', 'Backend\LoginController@adminLogout');

Route::get('/test','UserController@index');


