<?php
define('APP_NAME','MOIVE TICKET');
define('BASE_URL','http://localhost:8000');
define('DB_HOST','localhost');
define('DB_NAME','ticket_system');
define('DB_USER','root');
define('DB_PASS','infiniti');
