<?php
namespace Models;

use Connection\DB;
use PDOException;

class User
{
    private $table = 't_users';
    private $fields = ['user_id','r_role_id','name','email','email_verified_at','password','mobile_number','status'];
    /**
     * @param $uname
     * @param $pass
     * @return bool
     * To verify user name and password
     */
    public static function adminAuth($email,$password){
        // select a particular user by id
        try{
            $stmt = DB::getConnection()->prepare("SELECT * FROM t_users WHERE email=:email AND password=:password");
            $stmt->execute(['email' => $email,'password' => $password]);
            return $stmt->fetch();
        } catch (PDOException $e){
            echo "Error on user model auth function :".$e->getMessage();
        }

    }
}