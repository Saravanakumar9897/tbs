<?php
namespace Controllers;

use Models\User;
use Request\Request;
class UserController
{
    public function index(Request $request){
        echo 'hi';
    }
}