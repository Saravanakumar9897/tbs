<?php


namespace Controllers\Backend;


use Models\User;
use Request\Request;

class LoginController
{
    public function index(Request $request){
        if ($request->getSession('ADMIN_USER_DATA')!=false){
            export('backend/dashboard/dashboard',$request->getSession('ADMIN_USER_DATA'));
        } else{
            export('backend/authentication/login','');
        }
    }

    public function adminLogin(Request $request)
    {
        $formData = $request->getBody();
        $user = User::adminAuth($formData['userName'], $formData['userPassword']);
        if ($user!=""){
            export('backend/dashboard/dashboard',$user);
        } else {
            export('backend/authentication/login',['message'=>'Authentication Error!']);
        }
    }

    public function adminLogout(Request $request){
        $request->sessionTruncate();
        redirect('/admin');
    }
}